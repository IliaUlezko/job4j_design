Basic project job4j_junior
В проекте рассмотрены темы 
    - Структуры данных и алгоритмы
    - Ввод-вывод
    - SQL, JDBC
    - Garbage Collection
    - ООД